-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2022 at 05:51 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cee_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_acc`
--

CREATE TABLE `admin_acc` (
  `admin_id` int(11) NOT NULL,
  `admin_user` varchar(1000) NOT NULL,
  `admin_pass` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_acc`
--

INSERT INTO `admin_acc` (`admin_id`, `admin_user`, `admin_pass`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `course_tbl`
--

CREATE TABLE `course_tbl` (
  `cou_id` int(11) NOT NULL,
  `cou_name` varchar(1000) NOT NULL,
  `cou_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_tbl`
--

INSERT INTO `course_tbl` (`cou_id`, `cou_name`, `cou_created`) VALUES
(67, 'DATABASE MANAGEMENT SYSTEM', '2022-01-27 05:53:43'),
(68, 'PYTHON', '2022-01-27 05:54:00'),
(70, 'UNIX', '2022-01-27 05:54:56'),
(71, 'JAVA', '2022-01-27 05:55:16'),
(73, 'MANAGEMENT', '2022-01-29 04:37:16'),
(75, 'DAA', '2022-02-07 09:20:00');

-- --------------------------------------------------------

--
-- Table structure for table `examinee_tbl`
--

CREATE TABLE `examinee_tbl` (
  `exmne_id` int(11) NOT NULL,
  `exmne_fullname` varchar(1000) NOT NULL,
  `exmne_course` varchar(1000) NOT NULL,
  `exmne_gender` varchar(1000) NOT NULL,
  `exmne_birthdate` varchar(1000) NOT NULL,
  `exmne_year_level` varchar(1000) NOT NULL,
  `exmne_email` varchar(1000) NOT NULL,
  `exmne_password` varchar(1000) NOT NULL,
  `exmne_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examinee_tbl`
--

INSERT INTO `examinee_tbl` (`exmne_id`, `exmne_fullname`, `exmne_course`, `exmne_gender`, `exmne_birthdate`, `exmne_year_level`, `exmne_email`, `exmne_password`, `exmne_status`) VALUES
(9, 'Arun', '67', 'male', '2004-10-12', 'first year', 'student1@gmail.com', 'student1', 'active'),
(10, 'Bhumi', '68', 'female', '2001-08-03', 'third year', 'student2@gmail.com', 'student2', 'active'),
(11, 'Harsha', '68', 'male', '2001-10-12', 'third year', 'student3@gmail.com', 'student3', 'active'),
(12, 'Bhavya', '70', 'female', '2001-10-01', 'second year', 'student4@gmail.com', 'student4', 'active'),
(13, 'Yashwanth', '71', 'male', '2007-02-20', 'fourth year', 'student5@gmail.com', 'student5', 'active'),
(14, 'Manu', '71', 'male', '2000-01-11', 'fourth year', 'student6@gmail.com', 'student6', 'active'),
(15, 'Madhu', '67', 'male', '2004-04-08', 'second year', 'student7@gmail.com', 'student7', 'active'),
(16, 'Diwakar', '71', 'male', '2007-06-05', 'first year', 'student8@gmail.com', 'student8', 'active'),
(17, 'Vinay', '70', 'male', '2010-06-23', 'first year', 'student9@gmail.com', 'student9', 'active'),
(18, 'Rohith', '67', 'male', '2011-06-01', 'second year', 'student10@gmail.com', 'student10', 'active'),
(19, 'Bhumii', '67', 'female', '2022-01-05', 'first year', 'student11@gmail.com', 'student11', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_answers`
--

CREATE TABLE `exam_answers` (
  `exans_id` int(11) NOT NULL,
  `axmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `quest_id` int(11) NOT NULL,
  `exans_answer` varchar(1000) NOT NULL,
  `exans_status` varchar(1000) NOT NULL DEFAULT 'new',
  `exans_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_answers`
--

INSERT INTO `exam_answers` (`exans_id`, `axmne_id`, `exam_id`, `quest_id`, `exans_answer`, `exans_status`, `exans_created`) VALUES
(321, 9, 27, 50, ' All of the above', 'new', '2022-01-27 08:55:37'),
(322, 9, 27, 46, 'Database Management System', 'new', '2022-01-27 08:55:38'),
(323, 9, 27, 49, 'Edgar Frank Codd', 'new', '2022-01-27 08:55:38'),
(324, 9, 27, 47, 'Organized collection of data or information that can be accessed, updated, and managed', 'new', '2022-01-27 08:55:38'),
(325, 9, 27, 48, 'DBMS stores, modifies and retrieves data', 'new', '2022-01-27 08:55:38'),
(326, 18, 27, 48, 'DBMS is a collection of queries', 'new', '2022-01-28 18:16:39'),
(327, 18, 27, 49, 'Edgar Frank Codd', 'new', '2022-01-28 18:16:40'),
(328, 18, 27, 46, 'Data of Binary Management System', 'new', '2022-01-28 18:16:40'),
(329, 18, 27, 47, ' Organized collection of data that cannot be updated', 'new', '2022-01-28 18:16:40'),
(330, 18, 27, 50, ' Image oriented data', 'new', '2022-01-28 18:16:40'),
(331, 16, 24, 34, 'Object-oriented', 'new', '2022-01-29 03:53:14'),
(332, 16, 24, 32, 'Java is a platform-independent programming language', 'new', '2022-01-29 03:53:14'),
(333, 16, 24, 35, 'none of the mentioned', 'new', '2022-01-29 03:53:14'),
(334, 16, 24, 31, 'Guido van Rossum', 'new', '2022-01-29 03:53:14'),
(335, 16, 24, 33, 'JDK', 'new', '2022-01-29 03:53:14'),
(336, 13, 24, 34, 'Object-oriented', 'new', '2022-01-29 04:41:22'),
(337, 13, 24, 32, 'Java is a platform-independent programming language', 'new', '2022-01-29 04:41:22'),
(338, 13, 24, 35, 'none of the mentioned', 'new', '2022-01-29 04:41:22'),
(339, 13, 24, 33, 'JVM', 'new', '2022-01-29 04:41:22'),
(340, 13, 24, 31, 'Guido van Rossum', 'new', '2022-01-29 04:41:22'),
(341, 17, 25, 36, 'Unix is an operating system', 'new', '2022-01-29 11:19:33'),
(342, 17, 25, 39, 'ed', 'new', '2022-01-29 11:19:33'),
(343, 10, 26, 45, ' Indentation', 'new', '2022-01-29 12:06:46'),
(344, 10, 26, 43, 'no', 'new', '2022-01-29 12:06:46'),
(345, 10, 26, 44, 'Python code is neither compiled nor interpreted', 'new', '2022-01-29 12:06:46'),
(346, 10, 26, 41, 'Guido van Rossum', 'new', '2022-01-29 12:06:46'),
(347, 10, 26, 42, 'all of the mentioned', 'new', '2022-01-29 12:06:46'),
(348, 11, 26, 43, 'no', 'new', '2022-01-30 11:34:51'),
(349, 11, 26, 41, 'Guido van Rossum', 'new', '2022-01-30 11:34:51'),
(350, 11, 26, 42, 'all of the mentioned', 'new', '2022-01-30 11:34:51'),
(351, 11, 26, 44, 'Python code is both compiled and interpreted', 'new', '2022-01-30 11:34:51'),
(352, 11, 26, 45, ' Indentation', 'new', '2022-01-30 11:34:51'),
(353, 19, 27, 49, ' Charles Bachman', 'new', '2022-02-04 04:17:43'),
(354, 19, 27, 48, 'DBMS is a collection of queries', 'new', '2022-02-04 04:17:43'),
(355, 19, 27, 50, ' All of the above', 'new', '2022-02-04 04:17:43'),
(356, 19, 27, 47, 'Organized collection of data or information that can be accessed, updated, and managed', 'new', '2022-02-04 04:17:43'),
(357, 19, 27, 46, 'Database Management System', 'new', '2022-02-04 04:17:43'),
(358, 15, 27, 49, ' Charles Bachman', 'new', '2022-02-07 09:22:47'),
(359, 15, 27, 46, 'Database Management System', 'new', '2022-02-07 09:22:48'),
(360, 15, 27, 50, 'Text, files containing data', 'new', '2022-02-07 09:22:48'),
(361, 15, 27, 47, 'Collection of data or information without organizing', 'new', '2022-02-07 09:22:48'),
(362, 15, 27, 48, 'DBMS is a collection of queries', 'new', '2022-02-07 09:22:48');

-- --------------------------------------------------------

--
-- Table structure for table `exam_attempt`
--

CREATE TABLE `exam_attempt` (
  `examat_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `examat_status` varchar(1000) NOT NULL DEFAULT 'used'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_attempt`
--

INSERT INTO `exam_attempt` (`examat_id`, `exmne_id`, `exam_id`, `examat_status`) VALUES
(55, 9, 27, 'used'),
(56, 18, 27, 'used'),
(57, 16, 24, 'used'),
(58, 13, 24, 'used'),
(59, 17, 25, 'used'),
(60, 10, 26, 'used'),
(61, 11, 26, 'used'),
(62, 19, 27, 'used'),
(63, 15, 27, 'used');

-- --------------------------------------------------------

--
-- Table structure for table `exam_question_tbl`
--

CREATE TABLE `exam_question_tbl` (
  `eqt_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `exam_question` varchar(1000) NOT NULL,
  `exam_ch1` varchar(1000) NOT NULL,
  `exam_ch2` varchar(1000) NOT NULL,
  `exam_ch3` varchar(1000) NOT NULL,
  `exam_ch4` varchar(1000) NOT NULL,
  `exam_answer` varchar(1000) NOT NULL,
  `exam_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_question_tbl`
--

INSERT INTO `exam_question_tbl` (`eqt_id`, `exam_id`, `exam_question`, `exam_ch1`, `exam_ch2`, `exam_ch3`, `exam_ch4`, `exam_answer`, `exam_status`) VALUES
(31, 24, 'Who invented Java Programming?', 'Guido van Rossum', 'James Gosling', 'Dennis Ritchie', 'Bjarne Stroustrup', 'James Gosling', 'active'),
(32, 24, ' Which statement is true about Java?', 'Java is a sequence-dependent programming language', 'Java is a code dependent programming language', 'Java is a platform-dependent programming language', 'Java is a platform-independent programming language', 'Java is a platform-independent programming language', 'active'),
(33, 24, 'Which component is used to compile, debug and execute the java programs?', 'JRE', 'JIT', 'JDK', 'JVM', 'JDK', 'active'),
(34, 24, 'Which one of the following is not a Java feature?', 'Object-oriented', 'Use of pointers', 'Portable', 'Dynamic and Extensible', 'Use of pointers', 'active'),
(35, 24, 'Which of these cannot be used for a variable name in Java?', 'identifier & keyword', 'identifier', 'keyword', 'none of the mentioned', 'keyword', 'active'),
(36, 25, 'What is Unix?', 'Unix is a programming language', 'Unix is a software program', 'Unix is an operating system', 'Unix is a text editor', 'Unix is an operating system', 'active'),
(37, 25, 'The Unix shell is both _______ and _______ language.', ' scripting, interpreter', 'high level, low level', 'interactive, responsive', 'interpreter, executing', ' scripting, interpreter', 'active'),
(38, 25, ' In which language UNIX is written?', 'C++', 'C', 'JAVA', 'Python', 'C', 'active'),
(39, 25, ' Which of the following is the first UNIX editor?', 'vi', 'emacs', 'ex', 'ed', 'ed', 'active'),
(40, 25, ' Which of the following is not a feature of Unix?', 'multiuser', 'easy to use', 'multitasking', 'portability', 'easy to use', 'active'),
(41, 26, 'Who developed Python Programming Language?', 'Wick van Rossum', 'Rasmus Lerdorf', 'Guido van Rossum', 'Niene Stom', 'Guido van Rossum', 'active'),
(42, 26, 'Which type of Programming does Python support?', 'object-oriented programming', 'structured programming', 'functional programming', 'all of the mentioned', 'all of the mentioned', 'active'),
(43, 26, 'Is Python case sensitive when dealing with identifiers?', 'no', 'yes', 'machine dependent', 'none of the mentioned', 'no', 'active'),
(44, 26, ' Is Python code compiled or interpreted?', 'Python code is both compiled and interpreted', 'Python code is neither compiled nor interpreted', 'Python code is only compiled', 'Python code is only interpreted', 'Python code is neither compiled nor interpreted', 'active'),
(45, 26, 'Which of the following is used to define a block of code in Python language?', ' Indentation', 'Key', 'Brackets', 'All of the mentioned', ' Indentation', 'active'),
(46, 27, 'What is the full form of DBMS?', 'Data of Binary Management System', 'Database Management System', 'Database Management Service', 'Data Backup Management System', 'Database Management System', 'active'),
(47, 27, 'What is a database?', 'Organized collection of information that cannot be accessed, updated, and managed', 'Collection of data or information without organizing', 'Organized collection of data or information that can be accessed, updated, and managed', ' Organized collection of data that cannot be updated', 'Organized collection of data or information that can be accessed, updated, and managed', 'active'),
(48, 27, ' What is DBMS?', 'DBMS is a collection of queries', 'DBMS is a high-level language', 'DBMS is a programming language', 'DBMS stores, modifies and retrieves data', 'DBMS stores, modifies and retrieves data', 'active'),
(49, 27, ' Who created the first DBMS?', 'Edgar Frank Codd', ' Charles Bachman', 'Charles Babbage', 'Sharon B. Codd', ' Charles Bachman', 'active'),
(50, 27, 'Which type of data can be stored in the database?', ' Image oriented data', 'Text, files containing data', 'Data in the form of audio or video', ' All of the above', ' All of the above', 'active'),
(51, 30, 'What is management?', 'A', 'B', 'C', 'D', 'B', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_tbl`
--

CREATE TABLE `exam_tbl` (
  `ex_id` int(11) NOT NULL,
  `cou_id` int(11) NOT NULL,
  `ex_title` varchar(1000) NOT NULL,
  `ex_time_limit` varchar(1000) NOT NULL,
  `ex_questlimit_display` int(11) NOT NULL,
  `ex_description` varchar(1000) NOT NULL,
  `ex_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_tbl`
--

INSERT INTO `exam_tbl` (`ex_id`, `cou_id`, `ex_title`, `ex_time_limit`, `ex_questlimit_display`, `ex_description`, `ex_created`) VALUES
(24, 71, 'Java', '10', 5, 'Java Exam', '2022-01-27 05:56:21'),
(25, 70, 'Unix', '10', 5, 'Unix exam', '2022-01-27 06:03:26'),
(26, 68, 'Python', '10', 5, 'Python Exam', '2022-01-27 06:12:24'),
(27, 67, 'DBMS', '10', 5, 'DBMS exam', '2022-01-27 06:17:25');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks_tbl`
--

CREATE TABLE `feedbacks_tbl` (
  `fb_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `fb_exmne_as` varchar(1000) NOT NULL,
  `fb_feedbacks` varchar(1000) NOT NULL,
  `fb_date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedbacks_tbl`
--

INSERT INTO `feedbacks_tbl` (`fb_id`, `exmne_id`, `fb_exmne_as`, `fb_feedbacks`, `fb_date`) VALUES
(10, 9, 'Arun', 'thankyou!!', 'January 27, 2022'),
(11, 18, 'Anonymous', 'Very bad I failed in my exam.', 'January 28, 2022'),
(12, 13, 'Anonymous', 'HII', 'January 29, 2022'),
(13, 15, 'Madhu', 'bnsgdhj', 'February 07, 2022');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_acc`
--
ALTER TABLE `admin_acc`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `course_tbl`
--
ALTER TABLE `course_tbl`
  ADD PRIMARY KEY (`cou_id`);

--
-- Indexes for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  ADD PRIMARY KEY (`exmne_id`);

--
-- Indexes for table `exam_answers`
--
ALTER TABLE `exam_answers`
  ADD PRIMARY KEY (`exans_id`);

--
-- Indexes for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  ADD PRIMARY KEY (`examat_id`);

--
-- Indexes for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  ADD PRIMARY KEY (`eqt_id`);

--
-- Indexes for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  ADD PRIMARY KEY (`ex_id`);

--
-- Indexes for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  ADD PRIMARY KEY (`fb_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_acc`
--
ALTER TABLE `admin_acc`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course_tbl`
--
ALTER TABLE `course_tbl`
  MODIFY `cou_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  MODIFY `exmne_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `exam_answers`
--
ALTER TABLE `exam_answers`
  MODIFY `exans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=363;

--
-- AUTO_INCREMENT for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  MODIFY `examat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  MODIFY `eqt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  MODIFY `ex_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  MODIFY `fb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
